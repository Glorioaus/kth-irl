# 开发文档导航与维护规则

这里是文档分类索引，不是第二份进度表。**实际状态、执行权限和下一动作只看[CURRENT](D:/UGit/kth-irl-hybrid/docs/CURRENT.md)。**

## 1. 日常只维护四份主线文档

| 文档 | 唯一职责 | 何时更新 |
|---|---|---|
| [CURRENT](D:/UGit/kth-irl-hybrid/docs/CURRENT.md) | 实际源码/阶段、权限、证据、阻断和下一动作 | 每个工程检查点或交接 |
| [AG1-SPEC](D:/UGit/kth-irl-hybrid/docs/specs/agent-evaluator-delivery-v1.md) | 产品目标、范围、需求ID、架构边界和完成定义 | Owner采用或需求/范围改变时 |
| [AG1实施与验收计划](D:/UGit/kth-irl-hybrid/docs/plans/AG1/交付实施与验收计划.md) | 工作包、接口细化、文件/来源台账、验收场景 | 对应工作包开工和合同变更时 |
| [AG1新执行对话输入](D:/UGit/kth-irl-hybrid/docs/plans/AG1/新执行对话完整输入.md) | 新对话的阅读、保护、接续规则 | 恢复流程或入口改变时；不同步日常进度 |

阅读顺序：[AGENTS](D:/UGit/kth-irl-hybrid/AGENTS.md)顶部 → CURRENT → Spec → 实施计划当前包。换对话使用AG1输入；不要从其他标题含“完整输入”“当前”“下一步”的旧文档自行选择路线。

我们采用的是**规格驱动开发（spec-driven）**：需求 → 工作包/接口 → 实现 → 验收证据 → 交付。它是本仓工作方法，不表示已安装或采用某个外部Spec框架，不需要为“标准化”引入新工具链。

主计划和验收框架齐备，不等于所有函数签名、持久化字段、任务协议和测试数据已经冻结。技术细化是各包的首项工程工作，由执行者完成；不应为此再建另一份总体路线，也不要求开发者提供专业黄金答案。

## 2. 全体文档分层

本次整理前，`docs/`共82个文件，其中49个为历史检查点。数量多不意味着这些文件都要持续维护；以下按用途冻结维护责任，不移动文件或改变原引用路径。

| 分类 | 路径/入口 | 维护方式与效力 |
|---|---|---|
| 活跃主线 | 上述四份文档 | 是日常推进对象；是否获准开工只看CURRENT及Owner新指令 |
| 静态导航与纪律 | 根README、本索引、AGENTS顶部、`reference/README.md` | 只维护链接和职责，不复制“最新进度”；AGENTS历史正文不是新授权 |
| 方法及底层合同参考 | `specs/method-scope-v1.md`、`business-contract-v1.md`、`r2a-crl-rule-spec.md`、`r2b-frl-rule-spec.md`、`r2-rule-coverage.json` | 保留既有规则/接口来源，具体任务按需读取；阶段名和旧范围不能替代AG1 |
| 方法分歧台账 | [divergence-ledger](D:/UGit/kth-irl-hybrid/docs/divergence-ledger.md) | 按具名分歧追加记录，不能把整理导航当方法裁定 |
| 未冻结政策草案 | [org-d1-policy-draft-v0](D:/UGit/kth-irl-hybrid/docs/policy/org-d1-policy-draft-v0.md) | 不是已批准组织政策；其旧M阶段编号不套用到AG1，M5需要核实政策来源和采用依据 |
| 需求、资料解释及索引 | [reference/README](D:/UGit/kth-irl-hybrid/docs/reference/README.md)及该目录的CSV/说明 | 原件在`.local/reference/`；新增资料才追加具名来源，不逐阶段重写统计或重新采集 |
| 历史基线与裁决 | `M0-*.md`、`checkpoints/`、`decisions/runtime-v3.md` | 保留原文与身份；历史通过只在原范围内有效，不能删掉失败或升级当前通过状态 |
| 已完成的自包含收口 | [工作目录与收口说明](D:/UGit/kth-irl-hybrid/docs/工作目录与收口说明.md)、`specs/workspace-self-contained-v1.md` | 记录2026-09-17的事实，不继续维护其旧N1安排；正常运行不再依赖旧wheel位置 |
| 已退役执行方案 | [N1阶段计划](D:/UGit/kth-irl-hybrid/docs/plans/N1/真实可检查窄闭环阶段计划.md)、[N1执行输入](D:/UGit/kth-irl-hybrid/docs/plans/N1/新执行对话完整输入.md)、[夜间计划](D:/UGit/kth-irl-hybrid/docs/superpowers/plans/2026-09-09-kth-local-product-overnight.md) | 停止维护和执行，仅按具名问题引用技术经验 |
| 复审记录与未采用建议 | [产品可行性复审](D:/UGit/kth-irl-hybrid/docs/reviews/20260918-product-feasibility/整体产品与技术可行性复审.md)、同目录[旧F1输入](D:/UGit/kth-irl-hybrid/docs/reviews/20260918-product-feasibility/下一执行对话完整输入.md) | 分析/来源仍保留；“人工专业基准先于工程”建议被Owner工程先行决定取代，不继续执行F1 |

私有原件、聊天、Case、日志、备份不是文档垃圾；`.local/`被忽略不意味着可删。本次不扫描或整理该目录，不打开保护数据库。

## 3. 就绪不是一个总开关

| 层次 | 判断方式 |
|---|---|
| 项目规划就绪 | 目标、范围、需求—任务—验收映射、风险和接续规则齐全；可以交Owner采用 |
| 工作包可编码 | Owner已批准相应工程范围；执行者完成该包接口/字段/错误/恢复/测试数据和实际allowlist |
| 真实运行就绪 | 独立工程审核、新外发/宿主/工具/预算/窗口许可及安全条件成立 |
| 工程候选交付 | Codex新会话真实端到端和恢复验收通过，交付结果可追溯 |
| 专业采用 | 同事/业务方明确接受具体版本与适用范围，不是开发者代签 |

具体哪一层已经完成只写CURRENT。不可因“整理好了文档”就跳过采用/开工，也不可因尚未验证全部专业质量而无限延期无关离线工程。

## 4. 降低维护成本的规则

1. 同一事实只设一个权威位置：需求在Spec，接口/测试在计划，实际进度在CURRENT，原始证据在具名工件。
2. 旧方案逻辑归档，不随新实现同步改写。引用历史时同时注明其阶段、范围和是否已被取代。
3. 现有引用需要稳定：本次旧文档只在末尾追加状态提示，不改其既有正文/行序，不搬目录。
4. 当前包细化写回AG1计划，不新增“最终版2”“最新路线”“下一输入修正版”等平行文件。
5. 需求/范围变化才改Spec并登记变更；普通缺陷修复不另写一份项目规划。
6. 阶段日志、报告和交接放实际StageRoot，不把一次运行日志扩成新的永久说明书。
7. 不因文档维护改动重新审计旧业务或重跑未受影响测试。
8. 物理删除/移动另需具名清单、引用检查、独有内容保护和明确授权；本次没有删除候选自动放行。

## 5. 本次整理范围与来源

日期：2026-09-18。依据：Owner要求复盘开发文档就绪情况并降低维护成本。以下均为自有文档编辑，非外部代码导入；不回写M0 manifest，不改产品实现。

| 文件 | 本次动作 |
|---|---|
| 本索引 | 新增文档分层、维护规则和整理台账；不设第二份进度 |
| 根`README.md` | 精简为产品定位、CURRENT与文档入口；去掉重复权威表/纪律摘要 |
| `AGENTS.md` | 仅顶部增加文档分层导航及历史补充效力说明 |
| `docs/CURRENT.md` | 记录文档就绪层次、本次整理、剩余门和下一动作 |
| `docs/specs/agent-evaluator-delivery-v1.md` | 链接本索引，明确首次建档台账与本次维护台账分离；产品范围不变 |
| `docs/plans/AG1/交付实施与验收计划.md` | 去除重复当前进度；补每包细化检查及前置风险责任，澄清重复自述不新增独立佐证 |
| `docs/plans/AG1/新执行对话完整输入.md` | 将历史实现信息固定为具名基线，后续实际状态只读CURRENT |
| `docs/reference/README.md` | 修正仍指向N1的现行导航，区分历史采集与当前授权 |
| `docs/plans/N1/真实可检查窄闭环阶段计划.md` | 只追加退役提示，原正文保留 |
| `docs/plans/N1/新执行对话完整输入.md` | 只追加退役提示，原正文保留 |
| `docs/reviews/20260918-product-feasibility/下一执行对话完整输入.md` | 只追加F1建议失效提示，原正文保留 |
| `docs/superpowers/plans/2026-09-09-kth-local-product-overnight.md` | 只追加旧窗口失效提示，原正文保留 |
| `docs/工作目录与收口说明.md` | 只追加历史收口记录说明，原正文保留 |

没有删除/移动文件，不更新历史检查点、政策草案、原件、来源CSV或既有方法基线；未提交、未推送。检查结论见CURRENT，不在本索引另设动态通过清单。
